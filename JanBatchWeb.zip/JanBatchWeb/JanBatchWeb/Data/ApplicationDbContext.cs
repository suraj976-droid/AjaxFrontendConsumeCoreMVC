﻿using JanBatchWeb.Models;
using Microsoft.EntityFrameworkCore;

namespace JanBatchWeb.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {

        }

        public DbSet<Emp> emps { get; set; }
        public DbSet<Login> log { get; set; }

    }
}
