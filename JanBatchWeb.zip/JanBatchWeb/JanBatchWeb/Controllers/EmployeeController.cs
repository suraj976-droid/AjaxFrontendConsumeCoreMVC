﻿using JanBatchWeb.Data;
using JanBatchWeb.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace JanBatchWeb.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        private readonly ApplicationDbContext db;

        public EmployeeController(ApplicationDbContext db)
        {
            this.db = db;
        }

        [Route("AddEmp")]
        [HttpPost]
        public IActionResult AddEmployee(Emp e)
        {
            db.emps.Add(e);
            db.SaveChanges();
            return Ok("Added Successfully!!");
        }

        [Route("FetchEmp")]
        [HttpGet]
        public IActionResult FetchingEmployee()
        {
            var data = db.emps.ToList();
            return Ok(data);
        }

        [Route("DelEmp/{id}")]
        [HttpDelete]
        public IActionResult DeleteEmpById(int id)
        {
            var dt = db.emps.Find(id);
            db.emps.Remove(dt);
            db.SaveChanges();
            return Ok("Deleted");

        }

        // Add multiple emp
        [Route("AddEmps")]
        [HttpPost]
        public IActionResult AddEmployees(List<Emp> emps)
        {
            db.emps.AddRange(emps);
            db.SaveChanges();
            return Ok("Emps Added!");
        }

        // delete mutiple emp
        [Route("DeleteEmps")]
        [HttpDelete]
        public IActionResult DeleteEmps(List<int> ids)
        {
            var data = db.emps.Where(x => ids.Contains(x.EmpId)).ToList();
            db.emps.RemoveRange(data);
            db.SaveChanges();
            return Ok("Deleted");
        }

        //Login
        [Route("AddLogin")]
        [HttpPost]
        public IActionResult AddLogin(Login l)
        {
            db.log.Add(l);
            db.SaveChanges();
            return Ok("Added Successfully!!");
        }

        [Route("Login")]
        [HttpPost]
        public IActionResult Login(string email, string password)
        {
            var data = db.log.FirstOrDefault(l => l.email.Equals(email));

            if (data != null)
            {
                string userEmail = data.email;
                string userPass = data.password;
                if (userEmail.Equals(email) && userPass.Equals(password))
                {
                    return Ok("Logged In");
                }
                else
                {
                    return NotFound("Invalid");
                }
            }
            else
            {
                return NotFound("User not Found");
            }
        }

        // search 
        [Route("SearchByName/{name}")]
        [HttpPost]
        public IActionResult SeacrhByName(string name)
        {
            var data = db.emps.Where(s => s.EmpName.Contains(name)).ToList();
            return Ok(data);
        }


        // edit emp 
        [Route("EditEmp")]
        [HttpPost]
        public IActionResult UpdateEmp(Emp e)
        {
            //var data = db.emps.FirstOrDefault(x => x.EmpId.Equals(e.EmpId));

            //if(data == null)
            //{
            //    return NotFound("User not found");
            //}

            //data.EmpName = e.EmpName;
            //data.EmpEmail = e.EmpEmail;
            //data.EmpSalary = e.EmpSalary;

            db.emps.Update(e);
            db.SaveChanges();
            return Ok("Updated");
        }

        [Route("GetEmp/{id}")]
        [HttpGet]
        public IActionResult GetEmp(int id)
        {
            var data = db.emps.FirstOrDefault(e => e.EmpId.Equals(id));
            return Ok(data);
        }
    }
}
