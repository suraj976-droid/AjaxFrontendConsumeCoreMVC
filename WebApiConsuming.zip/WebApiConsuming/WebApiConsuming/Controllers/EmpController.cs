﻿using System.Net.Http.Json;
using System.Text;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using WebApiConsuming.Models;

namespace WebApiConsuming.Controllers
{
    public class EmpController : Controller
    {


        HttpClient client;
        public EmpController()
        {
            HttpClientHandler handler = new HttpClientHandler();
            handler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };

            client = new HttpClient(handler);
        }

        //public IActionResult Index()
        //{
        //    string url = "https://localhost:7017/api/Employee/FetchEmp";
        //    List<Emp> emp = new List<Emp>();
        //    HttpResponseMessage response = client.GetAsync(url).Result;
        //    if (response.IsSuccessStatusCode)
        //    {
        //        var result = response.Content.ReadAsStringAsync().Result;
        //        var obj = JsonConvert.DeserializeObject<List<Emp>>(result);
        //        if (obj != null)
        //        {
        //            emp = obj;
        //        }
        //    }
        //    return View(emp);
        //}

        public IActionResult Index()
        {
            return View();
        }

        // Fetching all data ajax
        public IActionResult FetchEmp()
        {
            string url = "https://localhost:7017/api/Employee/FetchEmp";
            HttpResponseMessage response = client.GetAsync(url).Result;

            if (response.IsSuccessStatusCode)
            {
                var result = response.Content.ReadAsStringAsync().Result;
                var empList = JsonConvert.DeserializeObject<List<Emp>>(result);
                return Json(empList);
            }

            return Json(new { error = "Failed to fetch data" });
        }

        // add emp sir method
        public IActionResult AddEmp(Emp e)
        {
            string url = "https://localhost:7017/api/Employee/AddEmp";
            var jsonData = JsonConvert.SerializeObject(e);
            StringContent content = new StringContent(jsonData, Encoding.UTF8, "application/json");
            HttpResponseMessage res = client.PostAsync(url, content).Result;

            if (res.IsSuccessStatusCode)
            {
                return Json(new { success = true, message = "Employee added successfully!" });
            }
            else
            {
                return Json(new { success = false, message = "Failed to add employee." });
            }
        }

        // Add Employees my method
        //public IActionResult AddEmp(Emp e)
        //{
        //    string url = "https://localhost:7017/api/Employee/AddEmp";

        //    var requestData = new
        //    {
        //        empId = e.empId,
        //        empName = e.empName,
        //        empEmail = e.empEmail,
        //        empSalary = e.empSalary
        //    };

        //    //Console.WriteLine(JsonConvert.SerializeObject(requestData));

        //    HttpResponseMessage res = client.PostAsJsonAsync(url, requestData).Result;

        //    if (res.IsSuccessStatusCode)
        //    {
        //        return Json(new { success = true, message = "Employee added successfully!" });
        //    }
        //    else
        //    {
        //        return Json(new { success = false, message = "Failed to add employee."});
        //    }
        //}



        // get particular employee
        public IActionResult GetEmp(int id)
        {
            string url = $"https://localhost:7017/api/Employee/GetEmp/{id}";
            HttpResponseMessage res = client.GetAsync(url).Result;

            if (res.IsSuccessStatusCode)
            {
                var data = res.Content.ReadAsStringAsync().Result;
                return Content(data, "application/json");
            }
            else
            {
                return Json(new { success = false, message = "Employee not found." });
            }
        }

        // edit
        public IActionResult EditEmp(Emp emp)
        {
            string url = "https://localhost:7017/api/Employee/EditEmp";
            var jsondata = JsonConvert.SerializeObject(emp);
            StringContent content = new StringContent(jsondata, Encoding.UTF8, "application/json");
            HttpResponseMessage res = client.PostAsync(url, content).Result;

            if (res.IsSuccessStatusCode)
            {
                return Json(new { success = true, message = "Employee updated successfully!" });
            }
            else
            {
                return Json(new { success = false, message = "Failed to update employee." });
            }
        }

        // delete 
        public IActionResult DeleteEmp(int id)
        {
            string url = "https://localhost:7017/api/Employee/DelEmp/";
            HttpResponseMessage response = client.DeleteAsync(url + id).Result;
            if (response.IsSuccessStatusCode)
            {
                return Json(new { success = true, message = "Employee Deleted successfully!" });
            }
            else
            {
                //return NotFound();
                return Json(new { success = false, message = "Employee Not Found!" });
            }
        }
    }
}

