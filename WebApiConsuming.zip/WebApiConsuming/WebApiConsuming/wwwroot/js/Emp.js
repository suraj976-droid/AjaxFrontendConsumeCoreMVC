﻿$(document).ready(function () {
    FetchData();
});

$('#btnModal').click(function () {
    $('#exampleModal').modal('show');
    $('#btnAddEmp').show();
    $('#btnUpdateEmp').hide();
    $('#exampleModalLabel').text("Add Employee")
});

$('#btnCloseModal').click(function () {
    $('#exampleModal').modal('hide');
});

$('#btnAddEmp').click(function () {

    var obj = $('#formData').serialize();

    $.ajax({
        url: '/Emp/AddEmp',
        type: 'POST',
        dataType: 'json',
        data: obj,
        contentType: 'Application/x-www-form-urlencoded;charset=utf-8',
        success: function (res) {

            if (res.success == "true") {

                alert(res.message);
                //toastr.success(res.message);
            }
            else {
                alert(res.message);
                //toastr.danger(res.message);
            }
            $("#exampleModal").modal('hide');
            FetchData();
        },
        error: function (xhr, status, error) {
            console.log("Error: ", error);
            console.log("Status: ", status);
            console.log("XHR: ", xhr.responseText);
            alert("Something went wrong!");
        }
    });
});

$('#btnUpdateEmp').click(function () {
    var obj = {
        empId: parseInt($("#empId").val()),
        empName: $("#empName").val(),
        empEmail: $("#empEmail").val(),
        empSalary: parseFloat($("#empSalary").val())
    };

    console.log(obj);

    $.ajax({
        url: '/Emp/EditEmp',
        type: 'POST',
        data: obj,
        contentType: 'Application/x-www-form-urlencoded;charset=utf-8',
        dataType: 'json',
        success: function (res) {
            if (res.success) {
                alert(res.message);
            } else {
                alert(res.message);
            }
            $("#exampleModal").modal('hide');
            FetchData();
        },
        error: function (xhr, status, error) {
            console.log("Error: ", error);
            console.log("Status: ", status);
            console.log("XHR: ", xhr.responseText);
            alert("Failed to update employee.");
        }
    });
});

function FetchData() {
    $.ajax({
        url: '/Emp/FetchEmp',
        type: 'GET',
        dataType: 'json',
        success: function (result) {
            console.log("AJAX Success: ", result);
            var obj = '';
            $.each(result, function (index, item) {
                obj += '<tr>';
                obj += '<td>' + item.empId + '</td>';
                obj += '<td>' + item.empName + '</td>';
                obj += '<td>' + item.empEmail + '</td>';
                obj += '<td>' + item.empSalary + '</td>';
                obj += '<td>' +
                    '<a class="btn btn-sm btn-danger mx-2" onclick="DeleteEmp(' + item.empId + ')" title="Delete">' +
                    '<i class="fas fa-trash"></i>' +
                    '</a>' +
                    '<a class="btn btn-sm btn-warning" onclick="EditEmp(' + item.empId + ')" title="Edit">' +
                    '<i class="fas fa-edit"></i>' +
                    '</a>' +
                    '</td>';
                obj += '</tr>';
            });

            console.log("Generated HTML:", obj);
            $('#myData').html(obj);
        },
        error: function (xhr, status, error) {
            console.log("Error: ", error);
            console.log("Status: ", status);
            console.log("XHR: ", xhr.responseText);
            alert("Something went wrong!");
        }
    });
}

function EditEmp(id) {
    $.ajax({
        url: '/Emp/GetEmp/' + id,
        type: 'GET',
        dataType: 'json',
        success: function (res) {
            $('#exampleModal').modal('show');
            $('#btnAddEmp').hide();
            $('#btnUpdateEmp').show();
            $('#exampleModalLabel').text("Edit Employee");

            $("#empId").val(res.empId);
            $("#empName").val(res.empName);
            $("#empEmail").val(res.empEmail);
            $("#empSalary").val(res.empSalary);
        },
        error: function () {
            alert("Something went wrong while fetching employee details!");
        }
    });
}

function DeleteEmp(id) {
    if (confirm("Are you sure you want to delete this Employee?")) {
        $.ajax({
            url: '/Emp/DeleteEmp?id=' + id,
            success: function () {
                alert("Employee Deleted Successfully");
                FetchData();
            },
            error: function () {
                alert("Something Went Wrong");
            }
        });

    }
    else {
        alert("Thanks");
    }
}

