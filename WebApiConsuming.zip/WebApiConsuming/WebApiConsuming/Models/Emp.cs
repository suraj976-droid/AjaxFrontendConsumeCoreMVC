﻿namespace WebApiConsuming.Models
{
    public class Emp
    {
        public int empId { get; set; }
        public string empName { get; set; }
        public string empEmail { get; set; }
        public string empSalary { get; set; }
    }

}
